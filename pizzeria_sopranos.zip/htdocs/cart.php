<?php
// 't Fruithuisje
//      Coded by Noah
//          All Rights Reserved
///////////////////////////////
			
	// If not logged in, redirect to login page
    if(!isset($_SESSION['user_id'])){
        header('Location: login.php');
        exit;
    } else {
        // Laat gebruikers de pagina zien!
    }
	
	// Pakt de huidige gebruiker zijn email uit table users via user ID (PDO Methode)
	$userid = $_SESSION['user_id'];
	$stmt = $connection->query("SELECT * FROM users WHERE user_id = '$userid' LIMIT 1");
	while ($row = $stmt->fetch()) {
    $email = $row['email'];
	} $stmt->execute();
	
	// If the user clicked the add to cart button on the product page we can check for the form data
	if (isset($_POST['product_id'], $_POST['quantity']) && is_numeric($_POST['product_id']) && is_numeric($_POST['quantity'])) {
    
	// Set the post variables so we easily identify them, also make sure they are integer
    $product_id = (int)$_POST['product_id'];
    $quantity = (int)$_POST['quantity'];
    
	// Prepare the SQL statement, we basically are checking if the product exists in our databaser
    $stmt = $connection->prepare('SELECT * FROM products WHERE product_id = ?');
    $stmt->execute([$_POST['product_id']]);
    
	// Fetch the product from the database and return the result as an Array
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    
	// Check if the product exists (array is not empty)
    if ($product && $quantity > 0) {
        
		// Product exists in database, now we can create/update the session variable for the cart
        if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
            if (array_key_exists($product_id, $_SESSION['cart'])) {
                
				// Product exists in cart so just update the quanity
                $_SESSION['cart'][$product_id] += $quantity;
            } else {
                
				// Product is not in cart so add it
                $_SESSION['cart'][$product_id] = $quantity;
            }
        } else {
            
			// There are no products in cart, this will add the first product to cart
            $_SESSION['cart'] = array($product_id => $quantity);
        }
    }
    // Prevent form resubmission...
    header('location: index.php?page=cart');
    exit;
	}

	// Remove product from cart, check for the URL param "remove", this is the product id, make sure it's a number and check if it's in the cart
	if (isset($_GET['remove']) && is_numeric($_GET['remove']) && isset($_SESSION['cart']) && isset($_SESSION['cart'][$_GET['remove']])) {
    
	// Remove the product from the shopping cart
    unset($_SESSION['cart'][$_GET['remove']]);
	}
	
	// Update product quantities in cart if the user clicks the "Update" button on the shopping cart page
	if (isset($_POST['update']) && isset($_SESSION['cart'])) {
    
	// Loop through the post data so we can update the quantities for every product in cart
    foreach ($_POST as $k => $v) {
        if (strpos($k, 'quantity') !== false && is_numeric($v)) {
            $id = str_replace('quantity-', '', $k);
            $quantity = (int)$v;
            // Always do checks and validation
            if (is_numeric($id) && isset($_SESSION['cart'][$id]) && $quantity > 0) {
                // Update new quantity
                $_SESSION['cart'][$id] = $quantity;
            }
        }
    }
    
	// Prevent form resubmission...
    header('location: index.php?page=cart');
    exit;
	}
	
	// Check the session variable for products in cart
	$products_in_cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : array();
	$products = array();
	$subtotal = 0.00;
	
	// If there are products in cart
	if ($products_in_cart) {
    
	// There are products in the cart so we need to select those products from the database
    // Products in cart array to question mark string array, we need the SQL statement to include IN (?,?,?,...etc)
    $array_to_question_marks = implode(',', array_fill(0, count($products_in_cart), '?'));
    $stmt = $connection->prepare('SELECT * FROM products WHERE product_id IN (' . $array_to_question_marks . ')');
    
	// We only need the array keys, not the values, the keys are the id's of the products
    $stmt->execute(array_keys($products_in_cart));
    
	// Fetch the products from the database and return the result as an Array
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
	// Calculate the subtotal
    foreach ($products as $product) {
        $subtotal += (float)$product['price'] * (int)$products_in_cart[$product['product_id']];
		}
	}
	
	// Send the user to the place order page if they click the Place Order button, also the cart should not be empty
	if (isset($_POST['placeorder']) && isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
		
		// --> Table: orders <--
		// For each product id & value, insert it in database table
		foreach ($_SESSION['cart'] as $k => $v) {
		$sql = 'INSERT INTO orders (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)';
		
		// Created variable $values, from the SQL query to put 'values' safer from SQL Injection
		// And making $_ variables possible here
		$values = ["NOT NULL", $k, $v, $subtotal];
		
		// Prepare & Execute to prevent SQL Injection
		$stmt = $connection->prepare($sql);
		$stmt->execute($values);
		}	
		
		// --> Table: orders_data <--
		// For each product id & value, insert it in database table
		foreach ($_SESSION['cart'] as $k => $v) {
		$sql2 = 'INSERT INTO orders_data (order_data_id, user_id, order_datum, firstname, lastname, street, postcode, telefoon, email) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)';
		
		// Created variable $values, from the SQL query to put 'values' safer from SQL Injection
		// And making $_ variables possible here
		$values2 = ["NOT NULL", $_SESSION['user_id'], "CURRENT_TIMESTAMP", $_POST['rg_firstname'], $_POST['rg_lastname'], $_POST['rg_street'], $_POST['rg_postcode'], $_POST['rg_telefoon'], $_POST['rg_email']];
		
		// Prepare & Execute to prevent SQL Injection
		$stmt = $connection->prepare($sql2);
		$stmt->execute($values2);
		}	
		
    header('Location: index.php?page=placeorder');
	unset($_SESSION["cart"]);
    exit;
	}
?>
            
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" name="keyword" content="'t Fruithuisje, HTML, CSS" alt="'t Fruithuisje" />
        <meta name="viewport" content="width=640, initial-scale=1.0 user-scalable=no" />
        <link rel="stylesheet" type="text/css" href="styles.css" />
        <title><?=$pagetitle;?> - Winkelwagentje</title>
    </head>
    <body>
        <!-- Navigation -->
        <nav>
            <ul>
                 <li><a class="logo"><img src="imgs/logo.png" style="width:150px"></a></li>
                 <li><a href="index.php">Home</a></li>
				 <li><a href="products.php">Producten</a></li>
				 <?php
					if(isset($_SESSION['user_id'])){
						echo '<li><a href="logout.php">Uitloggen</a></li>';
					} else {
						unset($_SESSION["user_id"]);
						header("Location: login.php");
					}
				?>
            </ul>
        </nav>
        
        <!-- Body Content -->    
        <section>
			<div class="card">
				<div class="section group">
					
					<!-- Content: 1 -->
					<div class="board">
						<h1>Winkelwagentje</h1>
							
						<!-- Winkelwagentje bijwerken -->
						<form action="index.php?page=cart" method="post">
							<table>
								<thead>
									<tr>
										<td colspan="2">Product</td>
										<td>Prijs</td>
										<td>Aantal</td>
										<td>Totaal</td>
									</tr>
								</thead>
							<tbody>
								
								<!-- Controleren of er producten zijn toegevoegd -->
								<?php if (empty($products)): ?>
									<tr>
										<td colspan="5" style="text-align:center;">Geen product in winkelwagentje</td>
									</tr>
								<?php else: ?>
								<?php foreach ($products as $product): ?>
								
								<!-- Product bijwerken -->
								<tr>
									<td class="img">
										<a href="index.php?page=product&id=<?=$product['product_id']?>">
											<img src="imgs/<?=$product['img']?>" width="50" height="50" alt="<?=$product['name']?>">
										</a>
									</td>
									<td>
										<a href="index.php?page=product&id=<?=$product['product_id']?>"><?=$product['name']?></a> <br>
										<a href="index.php?page=cart&remove=<?=$product['product_id']?>" class="remove">Verwijderen</a>
									</td>
									<td class="price">&euro;<?=$product['price']?></td>
									<td class="quantity">
										<input type="number" name="quantity-<?=$product['product_id']?>" value="<?=$products_in_cart[$product['product_id']]?>" min="1" max="<?=$product['quantity']?>" style="width:100%" placeholder="Voer product aantal in" required>
									</td>
									<td class="price">&euro;<?=$product['price'] * $products_in_cart[$product['product_id']]?></td>
								</tr>
								<?php endforeach; ?>
								<?php endif; ?>
							</tbody>
							</table>
							
							<!-- Subtotaal -->
							<div class="subtotal">
								<p><span class="text">Subtotaal:</span>
								<span class="price">&euro;<?=$subtotal?></span></p>
							</div><hr/>
							
							<!-- Bestelgegevens -->
							<h1>Bestelgegevens</h1>
									<div class="form-element">
										<p><input type="text" name="rg_firstname" placeholder="Voornaam" pattern="[a-zA-Z0-9]+" required /></p>
									</div>
					
									<div class="form-element">
										<p><input type="text" placeholder="Achternaam" name="rg_lastname" required /></p>
									</div>
		
									<div class="form-element">
										<p><input type="text" placeholder="Straat + Huisnr" name="rg_street" required /></p>
									</div>
									
									<div class="form-element">
										<p><input type="text" name="rg_postcode" placeholder="Postcode" required /></p>
									</div>
									
									<div class="form-element">
										<p><input type="text" name="rg_telefoon" placeholder="Telefoon" required /></p>
									</div>
									
									<div class="form-element">
										<p><input type="email" name="rg_email" value="<?php echo $email; ?>" placeholder="E-Mail" required /></p>
									</div>


							
							<!-- Toepassen Button -->
								<p><button type="submit" style="width:100%" name="update">Update</button></p>
								<p><button type="submit" style="width:100%" name="placeorder">Bestellen</button></p>
						</form>
					</div>
				</div>
			</div>
        </section>
        
         <!-- Footer -->
         <footer>
            Copyright © 2021 <?=$pagetitle;?> | Coded by Noah.
         </footer>
    </body>
</html>