<?php
// 't Fruithuisje
//      Coded by Noah
//          All Rights Reserved
///////////////////////////////
			
    define('USER', 'root');
    define('PASSWORD', '');
    define('HOST', 'localhost');
    define('DATABASE', 'fruithuisje');
    try {
        $connection = new PDO("mysql:host=".HOST.";dbname=".DATABASE, USER, PASSWORD);
    } catch (PDOException $e) {
        exit("Error: " . $e->getMessage());
    }
	
	// Global Pages Title
	$pagetitle = "Pizzeria S.";
	
	// Get the amount of items in the shopping cart, this will be displayed in the header.
	$num_items_in_cart = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;
?>