Als de [get] pagina's zoals bv. products.php of index.php NIET BESTAAT?
Dan wordt klant verwezen naar deze pagina.
