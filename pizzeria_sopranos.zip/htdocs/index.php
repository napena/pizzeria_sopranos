<?php
// 't Fruithuisje
//      Coded by Noah
//          All Rights Reserved
///////////////////////////////
			
    session_start();
	include('config.php');
	
	// Page is set to home (home.php) by default, so when the visitor visits that will be the page they see.
	$page = isset($_GET['page']) && file_exists($_GET['page'] . '.php') ? $_GET['page'] : 'home';
	// Include and show the requested page
	include $page . '.php';
	
	// If not logged in, redirect to login page
    if(!isset($_SESSION['user_id'])){
        header('Location: login.php');
        exit;
    } else {
        // Laat gebruikers de pagina zien!
    }
	
	// Pak de 4 meest recente toegevoegde producten
	$stmt = $connection->prepare('SELECT * FROM products ORDER BY date_added DESC LIMIT 4');
	$stmt->execute();
	$recently_added_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
            
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" name="keyword" content="'t Fruithuisje, HTML, CSS" alt="'t Fruithuisje" />
        <meta name="viewport" content="width=640, initial-scale=1.0 user-scalable=no" />
        <link rel="stylesheet" type="text/css" href="styles.css" />
        <title><?=$pagetitle;?> - Home</title>
    </head>
    <body>
        <!-- Navigation -->
        <nav>
            <ul>
				<!-- Winkelwagentje Icoon -->
				<div class="cart">
					<p><a href="index.php?page=cart">🛒</a><span><?=$num_items_in_cart?></span></p>
				</div>
				
                 <li><a class="logo"><img src="imgs/logo.png" style="width:150px"></a></li>
                 <li><a class="active" href="index.php">Home</a></li>
				 <li><a href="products.php">Producten</a></li>
				 <?php
					if(isset($_SESSION['user_id'])){
						echo '<li><a href="logout.php">Uitloggen</a></li>';
					} else {
						unset($_SESSION["user_id"]);
						header("Location: login.php");
					}
				?>
            </ul>
        </nav>
        
        <!-- Body Content -->    
        <section>
			<div class="card">
				<div class="section group">
					
					<!-- Content: 1 -->
					<div class="col span_1_of_2">
						<div class="board">	
							<h2>Meest Recente Producten</h2>
								<?php foreach ($recently_added_products as $product): ?>
									<a href="index.php?page=product&id=<?=$product['product_id']?>" class="product">
										<img src="imgs/<?=$product['img']?>" width="200" height="200" alt="<?=$product['name']?>">
										<span class="name"><?=$product['name']?></span>
										
										<span class="price">
											&euro;<?=$product['price']?>
											<?php if ($product['rrp'] > 0): ?>
											
											<span class="rrp">&euro;<?=$product['rrp']?></span>
											<?php endif; ?>
										</span>
									</a>
								<?php endforeach; ?>
						</div>
					</div>
			
				
					<!-- Content: 2 -->
					<div class="col span_1_of_2">
						Lored ipsum...<br>
						Lored ipsum...<br>
						Lored ipsum...<br>
						Lored ipsum...<br>
						Lored ipsum...<br>
					</div>
				
				</div>
			</div>
        </section>
        
         <!-- Footer -->
         <footer>
            Copyright © 2021 <?=$pagetitle;?> | Coded by Noah.
         </footer>
    </body>
</html>