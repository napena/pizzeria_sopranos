<?php
// 't Fruithuisje
//      Coded by Noah
//          All Rights Reserved
///////////////////////////////
			
    session_start();
    include('config.php');
	
	if(isset($_SESSION['user_id'])){
	header('Location: index.php');
	}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" name="keyword" content="'t Fruithuisje, HTML, CSS" alt="'t Fruithuisje" />
        <meta name="viewport" content="width=640, initial-scale=1.0 user-scalable=no" />
        <link rel="stylesheet" type="text/css" href="styles.css" />
        <title><?=$pagetitle;?></title>
    </head>
    <body>
        <!-- Navigation -->
        <nav>
            <ul>
                 <li><a class="logo"><img src="imgs/logo.png" style="width:150px"></a></li>
                 <li><a href="index.php">Home</a></li>
				 <li><a class="active" href="login.php">Inloggen</a></li>
                 <li><a href="register.php">Meld je aan</a></li>
            </ul>
        </nav>
        
        <!-- Body Content -->    
        <section>
			<div class="card">
				<div class="section group">
			
					<!-- Content: 1 -->
					<div class="col span_1_of_2">
						<center>
							<h3>Al een account? Log hier in</h3>
				
							<!-- Form: Inloggen -->
							<?php
							if (isset($_POST['login'])) {
								$username = $_POST['username'];
								$password = $_POST['password'];
								$query = $connection->prepare("SELECT * FROM users WHERE username=:username");
								$query->bindParam("username", $username, PDO::PARAM_STR);
								$query->execute();
								$result = $query->fetch(PDO::FETCH_ASSOC);
									
							if (!$result) {
								echo '<p class="error">Gebruikersnaam of wachtwoord combinatie is fout!</p>';
								} else {
							
							if (password_verify($password, $result['password'])) {
								$_SESSION['user_id'] = $result['user_id'];
									echo '<p class="success">U bent ingelogd!</p>';
									header("Location: index.php");
									} else {
										echo '<p class="error">Gebruikersnaam of wachtwoord combinatie is fout!</p>';
									}
								}
							}
							?>
								<form method="post" action="" name="signin-form">
									<div class="form-element">
											<p><input type="text" name="username" placeholder="Gebruikersnaam" pattern="[a-zA-Z0-9]+" required /></p>
									</div>
									
									<div class="form-element">
											<p><input type="password" placeholder="Wachtwoord" name="password" required /></p>
									</div>
									
									<!-- Form: Button -->
									<p><button type="submit" name="login" value="login">Log In</button></p>
								</form>
						</center>
					</div>
				
					<!-- Content: 2 -->
						<div class="col span_1_of_2">
							<div class="board">
								Lored ipsum...<br>
								Lored ipsum...<br>
								Lored ipsum...<br>
								Lored ipsum...<br>
								Lored ipsum...<br>
							</div>
						</div>
				
				</div>
			</div>
        </section>
        
         <!-- Footer -->
         <footer>
            Copyright © 2021 <?=$pagetitle;?> | Coded by Noah.
         </footer>
    </body>
</html>