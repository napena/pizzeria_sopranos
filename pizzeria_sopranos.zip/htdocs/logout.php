<?php
// 't Fruithuisje
//      Coded by Noah
//          All Rights Reserved
///////////////////////////////
			
	// Uitloggen
	session_start();
	unset($_SESSION["user_id"]);
	header("Location: login.php");
?>