<?php
// 't Fruithuisje
//      Coded by Noah
//          All Rights Reserved
///////////////////////////////
			
	// If not logged in, redirect to login page
    if(!isset($_SESSION['user_id'])){
        header('Location: login.php');
        exit;
    } else {
        // Laat gebruikers de pagina zien!
    }
?>
            
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" name="keyword" content="'t Fruithuisje, HTML, CSS" alt="'t Fruithuisje" />
        <meta name="viewport" content="width=640, initial-scale=1.0 user-scalable=no" />
        <link rel="stylesheet" type="text/css" href="styles.css" />
        <title><?=$pagetitle;?> - Bestelling geplaatst</title>
    </head>
    <body>
        <!-- Navigation -->
        <nav>
            <ul>
				<!-- Winkelwagentje Icoon -->
				<div class="cart">
					<p><a href="#">🛒</a><span><?=$num_items_in_cart?></span></p>
				</div>
				
                 <li><a class="logo"><img src="imgs/logo.png" style="width:150px"></a></li>
                 <li><a class="active" href="index.php">Home</a></li>
				 <li><a href="products.php">Producten</a></li>
				 <?php
					if(isset($_SESSION['user_id'])){
						echo '<li><a href="logout.php">Uitloggen</a></li>';
					} else {
						unset($_SESSION["user_id"]);
						header("Location: login.php");
					}
				?>
            </ul>
        </nav>
        
        <!-- Body Content -->    
        <section>
			<div class="card">
				<div class="section group">
					
					<!-- Content: 1 -->
					<div class="col span_1_of_2">
						<div class="board">	
							<h1>Bestelling geplaatst</h1>
							<p>Bedankt voor uw bestelling, u ontvangt binnenkort een e-mail met het factuur.</p>
						</div>
					</div>
			
				
					<!-- Content: 2 -->
					<div class="col span_1_of_2">
						<div class="board">	
							<h1>Wat wilt u doen?</h1>
							<p><a href="index.php"><button type="submit">Naar homepagina</button></a></p>
							<p><a href="products.php"><button type="submit">Naar producten</button></a></p>
						</div>
					</div>
				
				</div>
			</div>
        </section>
        
         <!-- Footer -->
         <footer>
            Copyright © 2021 <?=$pagetitle;?> | Coded by Noah.
         </footer>
    </body>
</html>