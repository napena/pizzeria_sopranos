<?php
// 't Fruithuisje
//      Coded by Noah
//          All Rights Reserved
///////////////////////////////

// Tip:
// Deze pagina wordt niet geopend als website
// 		Maar de inhoud van deze pagina wordt uit pagina 'products.php' gehaald
// 			door de parameter 'GET' toe te passen
			
	// If not logged in, redirect to login page
    if(!isset($_SESSION['user_id'])){
        header('Location: login.php');
        exit;
    } else {
        // Laat gebruikers de pagina zien!
    }
	
	// Check to make sure the id parameter is specified in the URL
	if (isset($_GET['id'])) {
    
	// Prepare statement and execute, prevents SQL injection
    $stmt = $connection->prepare('SELECT * FROM products WHERE product_id = ?');
    $stmt->execute([$_GET['id']]);
    
	// Fetch the product from the database and return the result as an Array
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    
	// Check if the product exists (array is not empty)
    if (!$product) {
        // Simple error to display if the id for the product doesn't exists (array is empty)
        exit('Product does not exist!');
		}
	} else {
    
	// Simple error to display if the id wasn't specified
    exit('Product does not exist!');
}
?>
            
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" name="keyword" content="'t Fruithuisje, HTML, CSS" alt="'t Fruithuisje" />
        <meta name="viewport" content="width=640, initial-scale=1.0 user-scalable=no" />
        <link rel="stylesheet" type="text/css" href="styles.css" />
        <title><?=$pagetitle;?> - <?=$product['name']?></title>
    </head>
    <body>
        <!-- Navigation -->
        <nav>
            <ul>
                 <li><a class="logo"><img src="imgs/logo.png" style="width:150px"></a></li>
                 <li><a href="index.php">Home</a></li>
				 <li><a class="active" href="products.php">Producten</a></li>
				 <?php
					if(isset($_SESSION['user_id'])){
						echo '<li><a href="logout.php">Uitloggen</a></li>';
					} else {
						unset($_SESSION["user_id"]);
						header("Location: login.php");
					}
				?>
            </ul>
        </nav>
        
        <!-- Body Content -->    
        <section>
			<div class="card">
				<div class="section group">
					
					<!-- Content: 1 -->
					<div class="col span_1_of_2">		
						<img src="imgs/<?=$product['img']?>" style="height: 100%; width: 100%" alt="<?=$product['name']?>">
					</div>
					
					<!-- Content: 2 -->
					<div class="col span_1_of_2">
						<div class="board">
						
							<!-- Product afbeelding -->
							<h1 class="name"><?=$product['name']?></h1>
							
							<!-- Product prijs -->
							<span class="price">
								&euro;<?=$product['price']?>
								<?php if ($product['rrp'] > 0): ?>
								<span class="rrp">&euro;<?=$product['rrp']?></span>
								<?php endif; ?>
							</span>
        
							<!-- Toevoegen aan winkelwagentje -->
							<form action="index.php?page=cart" method="post">
							<input type="number" name="quantity" value="1" min="1" max="<?=$product['quantity']?>" placeholder="Voer product aantal in" required>
							<input type="hidden" name="product_id" value="<?=$product['product_id']?>">
							<button type="submit">Toevoegen aan winkelwagentje</button>
							</form>
        
							<!-- Product omschrijving -->
							<div class="description">
								<?=$product['desc']?>
							</div>
						</div>
					</div>
				</div>
			</div>
        </section>
        
         <!-- Footer -->
         <footer>
            Copyright © 2021 <?=$pagetitle;?> | Coded by Noah.
         </footer>
    </body>
</html>


















