<?php
// 't Fruithuisje
//      Coded by Noah
//          All Rights Reserved
///////////////////////////////
			
    session_start();
	include('config.php');
	
	// If not logged in, redirect to login page
    if(!isset($_SESSION['user_id'])){
        header('Location: login.php');
        exit;
    } else {
        // Laat gebruikers de pagina zien!
    }
	
	// The amounts of products to show on each page
	$num_products_on_each_page = 4;

	// The current page, in the URL this will appear as index.php?page=products&p=1, index.php?page=products&p=2, etc...
	$current_page = isset($_GET['p']) && is_numeric($_GET['p']) ? (int)$_GET['p'] : 1;
	
	// Select products ordered by the date added
	$stmt = $connection->prepare('SELECT * FROM products ORDER BY date_added DESC LIMIT ?,?');
	
	// bindValue will allow us to use integer in the SQL statement, we need to use for LIMIT
	$stmt->bindValue(1, ($current_page - 1) * $num_products_on_each_page, PDO::PARAM_INT);
	$stmt->bindValue(2, $num_products_on_each_page, PDO::PARAM_INT);
	$stmt->execute();
	
	// Fetch the products from the database and return the result as an Array
	$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
	
	// Get the total number of products
	$total_products = $connection->query('SELECT * FROM products')->rowCount();
?>
            
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" name="keyword" content="'t Fruithuisje, HTML, CSS" alt="'t Fruithuisje" />
        <meta name="viewport" content="width=640, initial-scale=1.0 user-scalable=no" />
        <link rel="stylesheet" type="text/css" href="styles.css" />
        <title><?=$pagetitle;?> - Producten</title>
    </head>
    <body>
        <!-- Navigation -->
        <nav>
            <ul>
				<!-- Winkelwagentje Icoon -->
				<div class="cart">
					<p><a href="index.php?page=cart">🛒</a><span><?=$num_items_in_cart?></span></p>
				</div>
				
                 <li><a class="logo"><img src="imgs/logo.png" style="width:150px"></a></li>
                 <li><a href="index.php">Home</a></li>
				 <li><a class="active" href="products.php">Producten</a></li>
				 <?php
					if(isset($_SESSION['user_id'])){
						echo '<li><a href="logout.php">Uitloggen</a></li>';
					} else {
						unset($_SESSION["user_id"]);
						header("Location: login.php");
					}
				?>
            </ul>
        </nav>
        
        <!-- Body Content -->    
        <section>
			<div class="card">
				<div class="section group">
					
					<!-- Content: 1 -->
					<div class="col span_1_of_2">
						<div class="board">
							<h1>Producten Lijst</h1>
								<p><?=$num_products_on_each_page?> producten</p>
								<?php foreach ($products as $product): ?>
									<a href="index.php?page=product&id=<?=$product['product_id']?>" class="product">
										<img src="imgs/<?=$product['img']?>" width="200" height="200" alt="<?=$product['name']?>">
										<span class="name"><?=$product['name']?></span>
										
										<span class="price">
											&euro;<?=$product['price']?>
											<?php if ($product['rrp'] > 0): ?>
											
											<span class="rrp">&euro;<?=$product['rrp']?></span>
											<?php endif; ?>
										</span>
									</a>
								<?php endforeach; ?>
						</div>
					</div>
					
					<!-- Content: 2 -->
					<div class="col span_1_of_2">
						<input type="number" min="1" max="20" style="max-width:100%" placeholder="dit werkt nog nie maar..." required>
					</div>
				</div>
				
				<!-- Buttons: Volgende / Terug -->
				<?php if ($current_page > 1): ?>
					<p><a href="products.php?page=products&p=<?=$current_page-1?>"><button type="submit">Terug</button></a></p>
				<?php endif; ?>
        
				<?php if ($total_products > ($current_page * $num_products_on_each_page) - $num_products_on_each_page + count($products)): ?>
					<p><a href="products.php?page=products&p=<?=$current_page+1?>"><button type="submit">Volgende</button></a></p>
				<?php endif; ?>
			</div>
        </section>
        
         <!-- Footer -->
         <footer>
            Copyright © 2021 <?=$pagetitle;?> | Coded by Noah.
         </footer>
    </body>
</html>