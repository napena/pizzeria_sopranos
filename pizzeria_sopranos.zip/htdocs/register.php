<?php
// 't Fruithuisje
//      Coded by Noah
//          All Rights Reserved
///////////////////////////////
			
    session_start();
    include('config.php');
	
	if(isset($_SESSION['user_id'])){
	header('Location: index.php');
	}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" name="keyword" content="'t Fruithuisje, HTML, CSS" alt="'t Fruithuisje" />
        <meta name="viewport" content="width=640, initial-scale=1.0 user-scalable=no" />
        <link rel="stylesheet" type="text/css" href="styles.css" />
        <title><?=$pagetitle;?> - Aanmelden</title>
    </head>
    <body>
        <!-- Navigation -->
        <nav>
            <ul>
                 <li><a class="logo"><img src="imgs/logo.png" style="width:150px"></a></li>
                 <li><a href="index.php">Home</a></li>
				 <li><a href="login.php">Inloggen</a></li>
                 <li><a class="active" href="register.php">Meld je aan</a></li>
            </ul>
        </nav>
        
        <!-- Body Content -->    
        <section>
			<div class="card">
				<div class="section group">
			
					<!-- Content: 1 -->
					<div class="col span_1_of_2">
						<center>
							<h3>Geen lid? Meld je aan</h3>
				
							<!-- Form: Aanmelden -->
							<?php
							if (isset($_POST['register'])) {
								$username = $_POST['username'];
								$email = $_POST['email'];
								$password = $_POST['password'];
								$password_hash = password_hash($password, PASSWORD_BCRYPT);
								$query = $connection->prepare("SELECT * FROM users WHERE email=:email");
								$query->bindParam("email", $email, PDO::PARAM_STR);
								$query->execute();
							
							if ($query->rowCount() > 0) {
								echo '<p class="error">Dit E-Mail Adres bestaat al!</p>';
							}
        
							if ($query->rowCount() == 0) {
								$query = $connection->prepare("INSERT INTO users(username,password,email) VALUES (:username,:password_hash,:email)");
								$query->bindParam("username", $username, PDO::PARAM_STR);
								$query->bindParam("password_hash", $password_hash, PDO::PARAM_STR);
								$query->bindParam("email", $email, PDO::PARAM_STR);
								$result = $query->execute();
							
							if ($result) {
								echo '<p class="success">Succesvol aangemeld!</p>';
								} else {
									echo '<p class="error">Er is iets fout gegaan!</p>';
									}
								}
							}
							?>
								<form method="post" action="" name="signup-form">
									<div class="form-element">
										<p><input type="text" name="username" placeholder="Gebruikersnaam" pattern="[a-zA-Z0-9]+" required /></p>
									</div>
					
									<div class="form-element">
										<p><input type="email" placeholder="E-Mail" name="email" required /></p>
									</div>
		
									<div class="form-element">
										<p><input type="password" placeholder="Wachtwoord" name="password" required /></p>
									</div>

									<!-- Form: Button -->
										<p><button type="submit" name="register" value="register">Meld je aan</button></p>
								</form>
						</center>
					</div>
				
					<!-- Content: 2 -->
						<div class="col span_1_of_2">
							<div class="board">
								Lored ipsum...<br>
								Lored ipsum...<br>
								Lored ipsum...<br>
								Lored ipsum...<br>
								Lored ipsum...<br>
							</div>
						</div>
				
				</div>
			</div>
        </section>
        
         <!-- Footer -->
         <footer>
            Copyright © 2021 <?=$pagetitle;?> | Coded by Noah.
         </footer>
    </body>
</html>