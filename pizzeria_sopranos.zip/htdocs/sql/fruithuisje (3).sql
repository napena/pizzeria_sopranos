-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 08 dec 2021 om 08:52
-- Serverversie: 10.4.19-MariaDB
-- PHP-versie: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fruithuisje`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `orders`
--

CREATE TABLE `orders` (
  `order_id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `product_id` int(100) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `product_id`, `quantity`, `price`) VALUES
(34, 0, 2, '2', '29.98'),
(35, 0, 2, '3', '44.97'),
(36, 0, 2, '3', '44.97'),
(37, 0, 4, '7', '489.93'),
(38, 0, 2, '1', '14.99'),
(39, 0, 2, '1', '14.99'),
(40, 0, 2, '1', '14.99'),
(41, 0, 2, '1', '44.98'),
(42, 0, 1, '1', '44.98'),
(43, 0, 2, '2', '59.97'),
(44, 0, 1, '1', '59.97'),
(45, 0, 2, '2', '59.97'),
(46, 0, 1, '1', '59.97'),
(47, 0, 2, '2', '59.97'),
(48, 0, 1, '1', '59.97'),
(49, 0, 2, '2', '59.97'),
(50, 0, 1, '1', '59.97'),
(51, 0, 2, '1', '14.99'),
(52, 0, 2, '1', '14.99'),
(53, 0, 1, '1', '29.99');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `orders_data`
--

CREATE TABLE `orders_data` (
  `order_data_id` int(100) NOT NULL,
  `user_id` int(100) DEFAULT NULL,
  `order_datum` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `postcode` varchar(255) DEFAULT NULL,
  `telefoon` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `orders_data`
--

INSERT INTO `orders_data` (`order_data_id`, `user_id`, `order_datum`, `firstname`, `lastname`, `street`, `postcode`, `telefoon`, `email`) VALUES
(1, 0, '0', '0', '0', '0', '0', '0', '0'),
(2, 0, '0', '0', '0', '0', '0', '0', '0'),
(3, 0, '0', '0', '0', '0', '0', '0', '0'),
(4, 1, '0', '0', '0', '0', '0', '0', '0'),
(5, 1, '0', '0', '0', '0', '0', '0', '0'),
(6, 1, 'CURRENT_TIMESTAMP', '0', '0', '0', '0', '0', '0'),
(7, 1, 'CURRENT_TIMESTAMP', '0', '0', '0', '0', '0', '0'),
(8, 1, 'CURRENT_TIMESTAMP', 'Noah', '0', '0', '0', '0', '0'),
(9, 1, 'CURRENT_TIMESTAMP', 'Noah', '0', '0', '0', '0', '0'),
(10, 1, 'CURRENT_TIMESTAMP', 'Noah22', 'Apena', 'Bordewijkhove 29', '2717 XR', '0686209747', 'alaniapena@yahoo.com'),
(11, 1, 'CURRENT_TIMESTAMP', 'Noah22', 'Apena', 'Bordewijkhove 29', '2717 XR', '0686209747', 'alaniapena@yahoo.com'),
(12, 1, 'CURRENT_TIMESTAMP', 'Noah', 'Apena', 'Bordewijkhove 29', '2717 XR', '0686209747', 'alaniapena@yahoo.com'),
(13, 1, 'CURRENT_TIMESTAMP', 'Noah', 'Apena', 'Bordewijkhove 29', '2717 XR', '0686209747', 'alaniapena@yahoo.com'),
(14, 1, 'CURRENT_TIMESTAMP', 'Noah', 'Apena', 'Bordewijkhove 29', '2717 XR', '0686209747', 'alaniapena@yahoo.com');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `products`
--

CREATE TABLE `products` (
  `product_id` int(100) NOT NULL,
  `name` varchar(200) NOT NULL,
  `desc` text NOT NULL,
  `price` decimal(7,2) NOT NULL,
  `rrp` decimal(7,2) NOT NULL DEFAULT 0.00,
  `quantity` int(11) NOT NULL,
  `img` text NOT NULL,
  `date_added` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Gegevens worden geëxporteerd voor tabel `products`
--

INSERT INTO `products` (`product_id`, `name`, `desc`, `price`, `rrp`, `quantity`, `img`, `date_added`) VALUES
(1, 'Pizza Salami', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>\r\n<h3>Labore</h3>\r\n<ul>\r\n<li>Ut enim ad minim veniam</li>\r\n<li>Quis nostrud exercitation ullamco laboris </li>\r\n<li>Excepteur sint occaecat cupidatat</li>\r\n<li>Duis aute irure dolor in reprehenderit in voluptate</li>\r\n</ul>', '29.99', '0.00', 10, 'pizza_salami.jpg', '2019-03-13 17:55:22'),
(2, 'Pizza Champignon', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>\r\n<h3>Labore</h3>\r\n<ul>\r\n<li>Ut enim ad minim veniam</li>\r\n<li>Quis nostrud exercitation ullamco laboris </li>\r\n<li>Excepteur sint occaecat cupidatat</li>\r\n<li>Duis aute irure dolor in reprehenderit in voluptate</li>\r\n</ul>', '14.99', '0.00', 34, 'pizza_champignon.jpg', '2019-03-13 18:52:49'),
(4, 'Pizza Tomaat', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>\r\n<h3>Labore</h3>\r\n<ul>\r\n<li>Ut enim ad minim veniam</li>\r\n<li>Quis nostrud exercitation ullamco laboris </li>\r\n<li>Excepteur sint occaecat cupidatat</li>\r\n<li>Duis aute irure dolor in reprehenderit in voluptate</li>\r\n</ul>', '69.99', '0.00', 7, 'pizza_tomaat.jpg', '2019-03-13 17:42:04');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

CREATE TABLE `users` (
  `user_id` int(100) NOT NULL,
  `username` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `email`) VALUES
(0, 'test', '$2y$10$9g2apUBJolNNJSjNsCjwre7EyxsvsFWu4wjvaW0Wb.RiBnhDhGXIy', 'test@apena.nl'),
(1, 'noahapena', '$2y$10$57.YsnwC.cNQKSs8ZDf3AO74ViMjjD89DjxGSH7WJw3NnB7v16mAK', 'alaniapena@yahoo.com'),
(2, 'test2', '$2y$10$WV0HoudgL5GRDaud0MQAzu/14rk6f93T3IMnjrjmd/dpuaD2bXygC', 'test@test.de');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `user_id` (`user_id`) USING BTREE;

--
-- Indexen voor tabel `orders_data`
--
ALTER TABLE `orders_data`
  ADD PRIMARY KEY (`order_data_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexen voor tabel `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexen voor tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT voor een tabel `orders_data`
--
ALTER TABLE `orders_data`
  MODIFY `order_data_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT voor een tabel `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Beperkingen voor tabel `orders_data`
--
ALTER TABLE `orders_data`
  ADD CONSTRAINT `orders_data_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
